Unlocking Android - NetworkSocketServer
---------------------------------------

This is NOT an Android project.  
Rather, this is super simple socket server example - 
which can be run locally to connect to from Android 
(see NetworkExplorer for the Android side).
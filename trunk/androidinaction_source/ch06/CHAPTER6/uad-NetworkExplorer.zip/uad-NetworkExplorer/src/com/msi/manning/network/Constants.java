package com.msi.manning.network;

public class Constants {

    public static final String LOGTAG = "NetworkExplorer";
}
